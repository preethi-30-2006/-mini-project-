import streamlit as st
import joblib
import re
import numpy as np
import matplotlib.pyplot as plt

# Load saved models
vectorizer = joblib.load("models/vectorizer.joblib")
rf_model = joblib.load("models/rf_model.joblib")
xgb_model = joblib.load("models/xgb_model.joblib")
label_encoder = joblib.load("models/label_encoder.joblib")

# Preprocessing
def clean_text(t):
    t = str(t).lower()
    t = re.sub(r"http\S+", "", t)          # remove URLs
    t = re.sub(r"[^a-zA-Z0-9\s]", "", t)   # remove special chars
    return t.strip()

# Prediction
def predict_sentiment(text, model_choice):
    text_clean = clean_text(text)
    X_input = vectorizer.transform([text_clean])

    if model_choice == "Random Forest":
        probs = rf_model.predict_proba(X_input)[0]
    else:
        probs = xgb_model.predict_proba(X_input)[0]

    classes = label_encoder.classes_
    pred_label = classes[np.argmax(probs)]

    return pred_label, probs, classes

# Streamlit UI
st.title("📝 Sentiment Analysis on Uber + Myntra Reviews")
st.write("Enter a review (text or emojis) and choose model to predict sentiment.")

user_input = st.text_area("Enter your review:")
model_choice = st.radio("Choose Model", ["Random Forest", "XGBoost"])

if st.button("Predict"):
    if user_input.strip():
        label, probs, classes = predict_sentiment(user_input, model_choice)

        st.success(f"**Predicted Sentiment:** {label}")

        # Bar chart
        fig, ax = plt.subplots()
        ax.bar(classes, probs, color=['red', 'blue', 'green'])
        ax.set_ylabel("Probability")
        ax.set_title("Prediction Confidence")
        st.pyplot(fig)
    else:
        st.warning("Please enter a review text.")
